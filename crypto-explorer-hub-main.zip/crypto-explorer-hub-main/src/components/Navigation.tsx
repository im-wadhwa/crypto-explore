import { NavLink } from "@/components/NavLink";
import { Shield, Lock, Hash, Blocks, MessageSquare } from "lucide-react";

const Navigation = () => {
  const navItems = [
    { to: "/", label: "Encryption", icon: Lock },
    { to: "/cryptography", label: "Cryptography", icon: Shield },
    { to: "/hashing", label: "Hash & Blockchain", icon: Hash },
    { to: "/blockchain", label: "Blocks", icon: Blocks },
    { to: "/suggestions", label: "Suggestions", icon: MessageSquare },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-lg">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold bg-gradient-cyber bg-clip-text text-transparent">
              CryptoLearn
            </span>
          </div>
          
          <div className="flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground transition-all hover:text-foreground hover:bg-muted"
                activeClassName="text-primary bg-muted shadow-glow-primary"
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{label}</span>
              </NavLink>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
