import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Blocks, Link2, Database, Network } from "lucide-react";
import Navigation from "@/components/Navigation";

const Blockchain = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-cyber bg-clip-text text-transparent">
            Blocks & Blockchain
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            Dive deep into blockchain structure and how distributed ledgers work
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 max-w-6xl mx-auto mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="p-6 bg-card border-border shadow-glow-primary h-full">
              <div className="flex items-center gap-3 mb-4">
                <Blocks className="h-8 w-8 text-primary" />
                <h2 className="text-3xl font-bold">What is a Block?</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                A block is a container data structure that aggregates transactions for inclusion in the public ledger.
              </p>
              
              <div className="space-y-4">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-primary">Block Header</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• <strong className="text-foreground">Block Version:</strong> Indicates which rules to follow</li>
                    <li>• <strong className="text-foreground">Previous Block Hash:</strong> Links to the previous block</li>
                    <li>• <strong className="text-foreground">Merkle Root:</strong> Hash of all transactions</li>
                    <li>• <strong className="text-foreground">Timestamp:</strong> When block was created</li>
                    <li>• <strong className="text-foreground">Difficulty Target:</strong> Mining complexity</li>
                    <li>• <strong className="text-foreground">Nonce:</strong> Number used in mining</li>
                  </ul>
                </div>
                
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-secondary">Block Body</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• <strong className="text-foreground">Transaction Counter:</strong> Number of transactions</li>
                    <li>• <strong className="text-foreground">Transactions:</strong> List of all transactions in the block</li>
                    <li>• Each transaction is verified and hashed</li>
                  </ul>
                </div>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6 bg-card border-border shadow-glow-secondary h-full">
              <div className="flex items-center gap-3 mb-4">
                <Link2 className="h-8 w-8 text-secondary" />
                <h2 className="text-3xl font-bold">What is a Blockchain?</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                A blockchain is a distributed, immutable ledger consisting of a chain of blocks linked together cryptographically.
              </p>
              
              <div className="space-y-4">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-primary">Key Properties</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• <strong className="text-foreground">Immutability:</strong> Once added, data cannot be altered</li>
                    <li>• <strong className="text-foreground">Transparency:</strong> All transactions are visible to network</li>
                    <li>• <strong className="text-foreground">Decentralization:</strong> No single point of control</li>
                    <li>• <strong className="text-foreground">Consensus:</strong> Network agrees on valid transactions</li>
                  </ul>
                </div>
                
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-secondary">How Blocks Link</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Each block contains hash of previous block</li>
                    <li>• Creates a cryptographic chain</li>
                    <li>• Changing one block breaks all subsequent blocks</li>
                    <li>• Makes tampering nearly impossible</li>
                  </ul>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="max-w-6xl mx-auto mb-12"
        >
          <Card className="p-8 bg-gradient-tech border-border">
            <h2 className="text-3xl font-bold mb-6 text-center">How a Blockchain Works</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Database className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">1. Transaction Initiated</h3>
                <p className="text-sm text-muted-foreground">
                  User creates a transaction and broadcasts it to the network
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Network className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">2. Validation & Mining</h3>
                <p className="text-sm text-muted-foreground">
                  Network nodes validate and miners compete to add block
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Blocks className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">3. Block Added</h3>
                <p className="text-sm text-muted-foreground">
                  Verified block is added to chain and replicated across network
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="p-6 bg-card border-border">
              <h3 className="text-2xl font-bold mb-4">Types of Blockchains</h3>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-primary">Public Blockchain</h4>
                  <p className="text-sm text-muted-foreground">Open to anyone, fully decentralized (Bitcoin, Ethereum)</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary">Private Blockchain</h4>
                  <p className="text-sm text-muted-foreground">Restricted access, controlled by organization</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary">Consortium Blockchain</h4>
                  <p className="text-sm text-muted-foreground">Semi-private, controlled by group of organizations</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary">Hybrid Blockchain</h4>
                  <p className="text-sm text-muted-foreground">Combines public and private elements</p>
                </div>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="p-6 bg-card border-border">
              <h3 className="text-2xl font-bold mb-4">Real-World Applications</h3>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-secondary">Cryptocurrency</h4>
                  <p className="text-sm text-muted-foreground">Digital currencies like Bitcoin and Ethereum</p>
                </div>
                <div>
                  <h4 className="font-semibold text-secondary">Supply Chain</h4>
                  <p className="text-sm text-muted-foreground">Track products from manufacture to delivery</p>
                </div>
                <div>
                  <h4 className="font-semibold text-secondary">Healthcare</h4>
                  <p className="text-sm text-muted-foreground">Secure medical records and patient data</p>
                </div>
                <div>
                  <h4 className="font-semibold text-secondary">Smart Contracts</h4>
                  <p className="text-sm text-muted-foreground">Self-executing contracts with code-defined rules</p>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Blockchain;
