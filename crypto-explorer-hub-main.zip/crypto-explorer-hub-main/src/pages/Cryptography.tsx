import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Shield, FileKey, Eye, Check } from "lucide-react";
import Navigation from "@/components/Navigation";

const Cryptography = () => {
  const concepts = [
    {
      icon: Shield,
      title: "Digital Signatures",
      description: "A mathematical scheme for verifying the authenticity and integrity of digital messages or documents.",
      working: [
        "Sender creates a hash of the message",
        "Hash is encrypted with sender's private key (signature)",
        "Receiver decrypts signature with sender's public key",
        "Receiver compares decrypted hash with computed hash",
        "Match confirms authenticity and integrity"
      ]
    },
    {
      icon: FileKey,
      title: "Certificate Authority (CA)",
      description: "Trusted third party that issues digital certificates to verify the identity of entities on the internet.",
      working: [
        "Entity generates key pair and certificate request",
        "CA verifies entity's identity",
        "CA signs certificate with its private key",
        "Certificate contains entity's public key",
        "Others verify certificate using CA's public key"
      ]
    },
    {
      icon: Eye,
      title: "Steganography",
      description: "The practice of hiding secret information within an ordinary, non-secret file or message to avoid detection.",
      working: [
        "Select a cover medium (image, audio, video)",
        "Convert secret message to binary",
        "Embed secret bits into cover's least significant bits",
        "Cover medium appears unchanged to human eye",
        "Extract hidden message using reverse process"
      ]
    },
    {
      icon: Check,
      title: "Message Authentication Code (MAC)",
      description: "A short piece of information used to authenticate a message and verify its integrity and authenticity.",
      working: [
        "Sender and receiver share a secret key",
        "Sender computes MAC using message + secret key",
        "MAC is sent along with the message",
        "Receiver computes MAC using received message + shared key",
        "If MACs match, message is authentic and unmodified"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-cyber bg-clip-text text-transparent">
            Advanced Cryptography
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            Explore advanced cryptographic techniques and their real-world applications
          </p>
        </motion.div>

        <div className="grid gap-6 max-w-6xl mx-auto">
          {concepts.map((concept, index) => (
            <motion.div
              key={concept.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 bg-card border-border hover:shadow-glow-primary transition-all">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10 text-primary">
                    <concept.icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-2">{concept.title}</h3>
                    <p className="text-muted-foreground mb-4">{concept.description}</p>
                    
                    <div className="bg-muted/50 rounded-lg p-4">
                      <h4 className="font-semibold mb-3 text-primary">How It Works:</h4>
                      <ol className="space-y-2">
                        {concept.working.map((step, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <span className="text-primary font-mono font-semibold">{idx + 1}.</span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 max-w-6xl mx-auto"
        >
          <Card className="p-8 bg-gradient-tech border-border">
            <h2 className="text-3xl font-bold mb-6 text-center">Why These Matter</h2>
            <div className="grid md:grid-cols-2 gap-6 text-muted-foreground">
              <div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Security Layer</h3>
                <p>These techniques provide multiple layers of security, ensuring that even if one method is compromised, others remain intact.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Trust & Verification</h3>
                <p>They enable secure communication between parties who have never met, establishing trust in the digital realm.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Data Integrity</h3>
                <p>Ensure that data hasn't been tampered with during transmission or storage, critical for financial and legal transactions.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Modern Internet</h3>
                <p>These concepts power HTTPS, email encryption, software updates, and countless other everyday digital interactions.</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Cryptography;
