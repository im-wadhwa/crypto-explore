import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MessageSquare, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";

const Suggestions = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [suggestion, setSuggestion] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !email || !suggestion) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields before submitting.",
        variant: "destructive",
      });
      return;
    }

    // In a real application, this would send to a backend
    toast({
      title: "Suggestion Submitted!",
      description: "Thank you for your feedback. We'll review it soon.",
    });

    // Clear form
    setName("");
    setEmail("");
    setSuggestion("");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-cyber bg-clip-text text-transparent">
            Your Suggestions Matter
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            Help us improve CryptoLearn by sharing your ideas, feedback, or questions
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-2xl mx-auto"
        >
          <Card className="p-8 bg-card border-border shadow-glow-primary">
            <div className="flex items-center gap-3 mb-6">
              <MessageSquare className="h-8 w-8 text-primary" />
              <h2 className="text-2xl font-bold">Send Us Your Thoughts</h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="suggestion">Your Suggestion or Feedback</Label>
                <Textarea
                  id="suggestion"
                  placeholder="Share your ideas, report issues, or ask questions..."
                  value={suggestion}
                  onChange={(e) => setSuggestion(e.target.value)}
                  className="mt-2 min-h-[150px]"
                />
              </div>

              <Button type="submit" className="w-full gap-2">
                <Send className="h-4 w-4" />
                Submit Suggestion
              </Button>
            </form>
          </Card>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-8"
          >
            <Card className="p-6 bg-muted/50 border-border">
              <h3 className="text-xl font-semibold mb-4 text-center">What You Can Share</h3>
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-3xl mb-2">💡</div>
                  <h4 className="font-semibold mb-1">New Ideas</h4>
                  <p className="text-sm text-muted-foreground">Topics or features you'd like to see</p>
                </div>
                <div>
                  <div className="text-3xl mb-2">🐛</div>
                  <h4 className="font-semibold mb-1">Bug Reports</h4>
                  <p className="text-sm text-muted-foreground">Issues you encountered</p>
                </div>
                <div>
                  <div className="text-3xl mb-2">❓</div>
                  <h4 className="font-semibold mb-1">Questions</h4>
                  <p className="text-sm text-muted-foreground">Concepts you want clarified</p>
                </div>
              </div>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default Suggestions;
