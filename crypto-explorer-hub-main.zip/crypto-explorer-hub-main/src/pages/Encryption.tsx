import { useState } from "react";
import { motion } from "framer-motion";
import CryptoJS from "crypto-js";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Key, Lock, Unlock } from "lucide-react";
import Navigation from "@/components/Navigation";

const Encryption = () => {
  const [symmetricText, setSymmetricText] = useState("");
  const [symmetricKey, setSymmetricKey] = useState("");
  const [symmetricResult, setSymmetricResult] = useState("");
  
  const [asymmetricText, setAsymmetricText] = useState("");
  const [publicKey, setPublicKey] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [asymmetricResult, setAsymmetricResult] = useState("");

  const generateKeys = async () => {
    try {
      const keyPair = await window.crypto.subtle.generateKey(
        {
          name: "RSA-OAEP",
          modulusLength: 2048,
          publicExponent: new Uint8Array([1, 0, 1]),
          hash: "SHA-256",
        },
        true,
        ["encrypt", "decrypt"]
      );

      const publicKeyData = await window.crypto.subtle.exportKey("spki", keyPair.publicKey);
      const privateKeyData = await window.crypto.subtle.exportKey("pkcs8", keyPair.privateKey);

      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${btoa(String.fromCharCode(...new Uint8Array(publicKeyData)))}\n-----END PUBLIC KEY-----`;
      const privateKeyPem = `-----BEGIN PRIVATE KEY-----\n${btoa(String.fromCharCode(...new Uint8Array(privateKeyData)))}\n-----END PRIVATE KEY-----`;

      setPublicKey(publicKeyPem);
      setPrivateKey(privateKeyPem);
    } catch (e) {
      setAsymmetricResult("Key generation failed");
    }
  };

  const handleSymmetricEncrypt = () => {
    if (!symmetricText || !symmetricKey) return;
    const encrypted = CryptoJS.AES.encrypt(symmetricText, symmetricKey).toString();
    setSymmetricResult(encrypted);
  };

  const handleSymmetricDecrypt = () => {
    if (!symmetricResult || !symmetricKey) return;
    try {
      const decrypted = CryptoJS.AES.decrypt(symmetricResult, symmetricKey).toString(CryptoJS.enc.Utf8);
      setSymmetricResult(decrypted);
    } catch (e) {
      setSymmetricResult("Decryption failed - check your key");
    }
  };

  const handleAsymmetricEncrypt = async () => {
    if (!asymmetricText || !publicKey) return;
    try {
      const pemContents = publicKey.replace(/-----BEGIN PUBLIC KEY-----/, '').replace(/-----END PUBLIC KEY-----/, '').replace(/\s/g, '');
      const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
      
      const cryptoKey = await window.crypto.subtle.importKey(
        "spki",
        binaryDer,
        { name: "RSA-OAEP", hash: "SHA-256" },
        false,
        ["encrypt"]
      );

      const encoded = new TextEncoder().encode(asymmetricText);
      const encrypted = await window.crypto.subtle.encrypt(
        { name: "RSA-OAEP" },
        cryptoKey,
        encoded
      );

      setAsymmetricResult(btoa(String.fromCharCode(...new Uint8Array(encrypted))));
    } catch (e) {
      setAsymmetricResult("Encryption failed - check your public key");
    }
  };

  const handleAsymmetricDecrypt = async () => {
    if (!asymmetricResult || !privateKey) return;
    try {
      const pemContents = privateKey.replace(/-----BEGIN PRIVATE KEY-----/, '').replace(/-----END PRIVATE KEY-----/, '').replace(/\s/g, '');
      const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
      
      const cryptoKey = await window.crypto.subtle.importKey(
        "pkcs8",
        binaryDer,
        { name: "RSA-OAEP", hash: "SHA-256" },
        false,
        ["decrypt"]
      );

      const encryptedData = Uint8Array.from(atob(asymmetricResult), c => c.charCodeAt(0));
      const decrypted = await window.crypto.subtle.decrypt(
        { name: "RSA-OAEP" },
        cryptoKey,
        encryptedData
      );

      setAsymmetricResult(new TextDecoder().decode(decrypted));
    } catch (e) {
      setAsymmetricResult("Decryption failed - check your private key");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-cyber bg-clip-text text-transparent">
            Encryption & Decryption
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            Explore symmetric and asymmetric encryption methods with live demonstrations
          </p>
        </motion.div>

        <Tabs defaultValue="symmetric" className="max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="symmetric" className="gap-2">
              <Key className="h-4 w-4" />
              Symmetric Encryption
            </TabsTrigger>
            <TabsTrigger value="asymmetric" className="gap-2">
              <Lock className="h-4 w-4" />
              Asymmetric Encryption
            </TabsTrigger>
          </TabsList>

          <TabsContent value="symmetric">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6 bg-card border-border shadow-glow-primary">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="symText">Message</Label>
                    <Textarea
                      id="symText"
                      placeholder="Enter your message..."
                      value={symmetricText}
                      onChange={(e) => setSymmetricText(e.target.value)}
                      className="mt-2 font-mono"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="symKey">Secret Key</Label>
                    <Input
                      id="symKey"
                      type="password"
                      placeholder="Enter your secret key..."
                      value={symmetricKey}
                      onChange={(e) => setSymmetricKey(e.target.value)}
                      className="mt-2 font-mono"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={handleSymmetricEncrypt} className="flex-1 gap-2">
                      <Lock className="h-4 w-4" />
                      Encrypt
                    </Button>
                    <Button onClick={handleSymmetricDecrypt} variant="secondary" className="flex-1 gap-2">
                      <Unlock className="h-4 w-4" />
                      Decrypt
                    </Button>
                  </div>

                  {symmetricResult && (
                    <div>
                      <Label>Result</Label>
                      <Textarea
                        value={symmetricResult}
                        readOnly
                        className="mt-2 font-mono bg-muted"
                        rows={4}
                      />
                    </div>
                  )}
                </div>
              </Card>

              <Card className="mt-8 p-6 bg-muted/50 border-border">
                <h3 className="text-xl font-semibold mb-4 text-primary">How Symmetric Encryption Works</h3>
                <div className="space-y-3 text-muted-foreground">
                  <p>• <strong className="text-foreground">Same Key:</strong> Uses the same secret key for both encryption and decryption</p>
                  <p>• <strong className="text-foreground">Algorithm:</strong> This demo uses AES (Advanced Encryption Standard), a widely-used symmetric algorithm</p>
                  <p>• <strong className="text-foreground">Speed:</strong> Very fast and efficient for large amounts of data</p>
                  <p>• <strong className="text-foreground">Use Case:</strong> Ideal for encrypting files, databases, and secure communications where both parties share the key</p>
                  <p>• <strong className="text-foreground">Security:</strong> The key must be kept secret and shared securely between parties</p>
                </div>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="asymmetric">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6 bg-card border-border shadow-glow-secondary">
                <div className="space-y-4">
                  <Button onClick={generateKeys} variant="outline" className="w-full gap-2">
                    <Key className="h-4 w-4" />
                    Generate Key Pair
                  </Button>

                  <div>
                    <Label htmlFor="asymText">Message</Label>
                    <Textarea
                      id="asymText"
                      placeholder="Enter your message..."
                      value={asymmetricText}
                      onChange={(e) => setAsymmetricText(e.target.value)}
                      className="mt-2 font-mono"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="pubKey">Public Key</Label>
                    <Textarea
                      id="pubKey"
                      placeholder="Generate or paste public key..."
                      value={publicKey}
                      onChange={(e) => setPublicKey(e.target.value)}
                      className="mt-2 font-mono text-xs"
                      rows={4}
                    />
                  </div>

                  <div>
                    <Label htmlFor="privKey">Private Key</Label>
                    <Textarea
                      id="privKey"
                      placeholder="Generate or paste private key..."
                      value={privateKey}
                      onChange={(e) => setPrivateKey(e.target.value)}
                      className="mt-2 font-mono text-xs"
                      rows={4}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={handleAsymmetricEncrypt} className="flex-1 gap-2">
                      <Lock className="h-4 w-4" />
                      Encrypt
                    </Button>
                    <Button onClick={handleAsymmetricDecrypt} variant="secondary" className="flex-1 gap-2">
                      <Unlock className="h-4 w-4" />
                      Decrypt
                    </Button>
                  </div>

                  {asymmetricResult && (
                    <div>
                      <Label>Result</Label>
                      <Textarea
                        value={asymmetricResult}
                        readOnly
                        className="mt-2 font-mono bg-muted text-xs"
                        rows={4}
                      />
                    </div>
                  )}
                </div>
              </Card>

              <Card className="mt-8 p-6 bg-muted/50 border-border">
                <h3 className="text-xl font-semibold mb-4 text-secondary">How Asymmetric Encryption Works</h3>
                <div className="space-y-3 text-muted-foreground">
                  <p>• <strong className="text-foreground">Key Pair:</strong> Uses two mathematically related keys - public and private</p>
                  <p>• <strong className="text-foreground">Algorithm:</strong> This demo uses RSA (Rivest-Shamir-Adleman), the most common asymmetric algorithm</p>
                  <p>• <strong className="text-foreground">Encryption:</strong> Data encrypted with the public key can only be decrypted with the private key</p>
                  <p>• <strong className="text-foreground">Use Case:</strong> Perfect for secure key exchange, digital signatures, and SSL/TLS certificates</p>
                  <p>• <strong className="text-foreground">Security:</strong> Public key can be shared openly, but private key must remain secret</p>
                  <p>• <strong className="text-foreground">Speed:</strong> Slower than symmetric encryption, often used to exchange symmetric keys</p>
                </div>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Encryption;
