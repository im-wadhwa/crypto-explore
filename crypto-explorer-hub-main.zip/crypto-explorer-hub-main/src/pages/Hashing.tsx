import { useState } from "react";
import { motion } from "framer-motion";
import CryptoJS from "crypto-js";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Hash, Key, Clock, Lock } from "lucide-react";
import Navigation from "@/components/Navigation";

const Hashing = () => {
  const [inputText, setInputText] = useState("");
  const [sha256Hash, setSha256Hash] = useState("");
  const [md5Hash, setMd5Hash] = useState("");

  const handleHash = () => {
    if (!inputText) return;
    setSha256Hash(CryptoJS.SHA256(inputText).toString());
    setMd5Hash(CryptoJS.MD5(inputText).toString());
  };

  const concepts = [
    {
      icon: Hash,
      title: "Hash Functions",
      description: "One-way mathematical functions that convert any input into a fixed-size string of bytes.",
      features: [
        "Deterministic: Same input always produces same hash",
        "Fast computation but impossible to reverse",
        "Small input changes create completely different hashes",
        "Collision-resistant: Hard to find two inputs with same hash"
      ]
    },
    {
      icon: Key,
      title: "Nonce (Number Once)",
      description: "A random or semi-random number used once in cryptographic communication to prevent replay attacks.",
      features: [
        "Used in blockchain mining to find valid block hashes",
        "Prevents attackers from reusing old authentication messages",
        "Combined with other data before hashing",
        "Critical for proof-of-work consensus mechanisms"
      ]
    },
    {
      icon: Clock,
      title: "Timestamp",
      description: "Records the exact time when a transaction or block was created, ensuring chronological order.",
      features: [
        "Establishes order of events in the blockchain",
        "Prevents backdating of transactions",
        "Helps validate block creation time",
        "Essential for time-sensitive smart contracts"
      ]
    },
    {
      icon: Lock,
      title: "Merkle Tree",
      description: "A tree structure where each leaf node is a hash of data, and each non-leaf node is a hash of its children.",
      features: [
        "Efficiently verifies large sets of data",
        "Used in blockchain to hash all transactions in a block",
        "Allows quick verification of specific transactions",
        "Root hash represents entire tree structure"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-cyber bg-clip-text text-transparent">
            Hashing & Blockchain Basics
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            Understand the fundamental building blocks of blockchain technology
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="max-w-4xl mx-auto mb-12"
        >
          <Card className="p-6 bg-card border-border shadow-glow-primary">
            <h2 className="text-2xl font-bold mb-4">Try Hash Functions</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="hashInput">Input Text</Label>
                <Input
                  id="hashInput"
                  placeholder="Enter any text to hash..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="mt-2"
                />
              </div>
              
              <Button onClick={handleHash} className="w-full gap-2">
                <Hash className="h-4 w-4" />
                Generate Hashes
              </Button>

              {sha256Hash && (
                <div className="space-y-3">
                  <div>
                    <Label>SHA-256 Hash</Label>
                    <div className="mt-2 p-3 bg-muted rounded-lg font-mono text-xs break-all text-primary">
                      {sha256Hash}
                    </div>
                  </div>
                  <div>
                    <Label>MD5 Hash</Label>
                    <div className="mt-2 p-3 bg-muted rounded-lg font-mono text-xs break-all text-secondary">
                      {md5Hash}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Notice: Even a tiny change in input creates a completely different hash!
                  </p>
                </div>
              )}
            </div>
          </Card>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {concepts.map((concept, index) => (
            <motion.div
              key={concept.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <Card className="p-6 bg-card border-border hover:shadow-glow-secondary transition-all h-full">
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 rounded-lg bg-primary/10 text-primary">
                    <concept.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{concept.title}</h3>
                  </div>
                </div>
                <p className="text-muted-foreground mb-4">{concept.description}</p>
                <ul className="space-y-2">
                  {concept.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm">
                      <span className="text-primary mt-1">•</span>
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-12 max-w-6xl mx-auto"
        >
          <Card className="p-8 bg-gradient-tech border-border">
            <h2 className="text-3xl font-bold mb-6 text-center">How They Work Together in Blockchain</h2>
            <div className="space-y-4 text-muted-foreground">
              <div className="flex items-start gap-3">
                <span className="text-2xl font-bold text-primary">1</span>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Transaction Creation</h3>
                  <p>User initiates a transaction with timestamp and nonce included</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-2xl font-bold text-primary">2</span>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Merkle Tree Formation</h3>
                  <p>Multiple transactions are hashed and organized into a Merkle tree structure</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-2xl font-bold text-primary">3</span>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Block Creation</h3>
                  <p>Merkle root, timestamp, nonce, and previous block hash are combined</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-2xl font-bold text-primary">4</span>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Mining Process</h3>
                  <p>Miners adjust the nonce repeatedly to find a hash meeting difficulty requirements</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-2xl font-bold text-primary">5</span>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Verification</h3>
                  <p>Network nodes verify the hash, transactions, and add block to the chain</p>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Hashing;
